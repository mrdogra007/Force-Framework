<!-- <?php echo $force_framework_version ?> Header -->
<?php include 'force-intro.php';?>

<main role="main">
	<div class="container">
		
		<!-- <?php echo $force_framework_version ?> working guide -->
		<div class="horizontal">
			<div class="verticals twelve">
				<h3 class="force-text-center purple">How to start with Force Framework</h3>
			</div>
		</div>
		
		<!-- <?php echo $force_framework_version ?> Files and the codes -->
		<div class="horizontal m-t-30">
			<div class="verticals twelve">
				<span class="caption m-t-30">Files and the codes</span>
				<small class="green">Copy the files and the codes path</small>
				<script src="https://gist.github.com/mrdogra007/352e61ec73e02e71c34d3d107b13ca0e.js"></script>
			</div>
		</div>
		
		<!-- <?php echo $force_framework_version ?> Minimal layout template -->	
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Minimal layout template</span>
				<small class="green">Copy the syntax for minimal layout</small>
				<script src="https://gist.github.com/mrdogra007/0a02277d194b7ca8890358dd388c6b8e.js"></script>
			</div>
		</div>
		
		<!-- <?php echo $force_framework_version ?> Basic layout template -->
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Basic layout template</span>
				<small class="green">Copy the syntax for basic layout</small>
				<script src="https://gist.github.com/mrdogra007/1ec04ca17b9b5c2b2b7a8f37ce5b8d70.js"></script>
			</div>
		</div>
		
		<!-- <?php echo $force_framework_version ?> Complete layout template -->
		<div class="horizontal m-t-30">
			<div class="verticals twelve">
				<span class="caption m-t-30">Complete layout template</span>
				<small class="green">Copy the syntax for full layout</small>
				<script src="https://gist.github.com/mrdogra007/34fe6ed9bd71ac7448f5a554c01c85aa.js"></script>
			</div>
		</div>
		
	</div>
</main>