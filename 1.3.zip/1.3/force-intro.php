<header role="header" class="force-intro">
	<div class="container">
		
		<!-- <?php echo $force_framework_version ?> introduction -->
		<div class="horizontal">
			<div class="vertical">
				<div class="force-box">
					<div class="force-box-container">
						<img src="http://cloud.dograsweblog.com/force-framework/600x600.png" class="fit-image" alt="Force Framework" data-title="Force Framework" />
						<h1 class="force-text-center orange"><?php echo $force_framework_version ?></h1>
						<h3 class="force-text-center">A lightweight and fast HTML/CSS Framework designed for the Designers &amp; Developers to compete with Performance</h3>
						<ul class="inline">
							<li><span class="badge bg-purple">Fast Pageload</span></li>
							<li><span class="badge bg-purple">Light Weight</span></li>
							<li><span class="badge bg-purple">Responsive</span></li>
							<li><span class="badge bg-purple">Easy to Embed</span></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</header>