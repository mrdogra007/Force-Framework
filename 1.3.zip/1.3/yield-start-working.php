<!-- <?php echo $force_framework_version ?> Header -->
<?php include 'force-intro.php';?>

<main role="main">
	<div class="container">
		
		<!-- <?php echo $force_framework_version ?> working guide -->
		<div class="horizontal">
			<div class="verticals ten offset-by-one">
				<h3 class="force-text-center purple">How to start with Force Framework</h3>
				<small class="green">Copy the syntax for layout</small>
				<script src="https://gist.github.com/mrdogra007/67cb341e3ded369e6317f2ce185042ad.js"></script>
			</div>
		</div>
		
		<!-- Full width card - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption">Style for cards</span>
				
				<div class="card full">
					<div class="card-data">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				<div class="card full">
					<small class="green">Full width card layout</small>
					<script src="https://gist.github.com/mrdogra007/3b7ee5f01b17bd2f1e86ad4ef6071b4a.js"></script>
				</div>
					
			</div>
		</div>
		
		<!-- Half width card - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">			
				<div class="card half">
					<div class="card-data">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card half">
					<div class="card-data">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card full">
					<small class="green">Half width card layout</small>
					<script src="https://gist.github.com/mrdogra007/4dd442a71fa053cde34c1272604e45d1.js"></script>
				</div>
			</div>
		</div>
		
		<!-- One third width card - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">		
				<div class="card one-third">
					<div class="card-data">
						<h4 class="orange">Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card one-third">
					<div class="card-data">
						<h4 class="blue">Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card one-third">
					<div class="card-data">
						<h4 class="green">Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card full">
					<small class="green">One third width card layout</small>
					<script src="https://gist.github.com/mrdogra007/36b34ebafe9791f7f105042eee7f96d2.js"></script>
				</div>
			</div>
		</div>
		
		<!-- Colored background card - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">	
				<span class="caption m-t-30">Style for cards</span>
				
				<div class="card one-fourth">
					<div class="card-data bg-orange">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card one-fourth">
					<div class="card-data bg-violet">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card one-fourth">
					<div class="card-data bg-green">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card one-fourth">
					<div class="card-data bg-blue">
						<h4>Contrary to popular belief</h4>
						<p>Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
					</div>
				</div>
				
				<div class="card card-full">
					<small class="green">Colored background card layout</small>
					<script src="https://gist.github.com/mrdogra007/d6ec4f5eb52ac78e9373338fdf618221.js"></script>
				</div>
			</div>
		</div>
		
		<!-- Typography heading tags - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Typography for headding tags &lt;h1&gt; to &lt;h6&gt;</span>
				<h1>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h1>
				<h2>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h2>
				<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h3>
				<h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h4>
				<h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h5>
				<h6>Lorem Ipsum is simply dummy text of the printing and typesetting industry</h6>
			</div>
			
			<div class="verticals twelve">
				<small class="green">Typography for headding tags</small>
				<script src="https://gist.github.com/mrdogra007/5fc024de0026a051b061e142ed6f1f14.js"></script>
			</div>
		</div>
		
		<!-- Typography for paragpraph tags - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Typography for &lt;p&gt;</span>
				<p class="large">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				<p class="orange">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				<p class="small">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				<p class="blue small">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
			</div>
			
			<div class="verticals twelve">
				<small class="green">Typography for paragpraph tags</small>
				<script src="https://gist.github.com/mrdogra007/59cd750806b17babe9f87e71cac204eb.js"></script>
			</div>
		</div>
		
		<!-- Typography for paragpraph with heading tags - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Typography for &lt;p&gt; using [class="h1 to h6"]</span>
				<p class="h1 orange">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
				<p class="h2 blue">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
				<p class="h3 green">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
				<p class="h4 purple">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
				<p class="h5 pink">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
				<p class="h6">Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
			</div>
			
			<div class="verticals twelve">
				<small class="green">Typography for paragpraph with heading tags</small>
				<script src="https://gist.github.com/mrdogra007/7908358c209382428e41d02f1301bb21.js"></script>
			</div>
		</div>
		
		<!-- Style for badges - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for badges</span>
			</div>
		</div>
		<div class="horizontal">	
			<div class="verticals six">
				<ul class="inline">
					<li><span class="badge">Fast Pageload</span></li>
					<li><span class="badge">Light Weight</span></li>
					<li><span class="badge">Responsive</span></li>
					<li><span class="badge">Easy to Embed</span></li>
				</ul>
				<ul class="inline">
					<li><span class="badge small">Fast Pageload</span></li>
					<li><span class="badge small">Light Weight</span></li>
					<li><span class="badge small">Responsive</span></li>
					<li><span class="badge small">Easy to Embed</span></li>
				</ul>
				<ul class="inline m-t-20">
					<li><span class="badge large">Fast Pageload</span></li>
					<li><span class="badge large">Light Weight</span></li>
					<li><span class="badge large">Responsive</span></li>
					<li><span class="badge large">Easy to Embed</span></li>
				</ul>
				<ul class="inline m-t-20">
					<li><span class="badge bg-orange large">Fast Pageload</span></li>
					<li><span class="badge bg-purple large">Light Weight</span></li>
					<li><span class="badge bg-pink large">Responsive</span></li>
					<li><span class="badge bg-red large">Fast Pageload</span></li>
					<li><span class="badge bg-blue large">Light Weight</span></li>
					<li><span class="badge bg-green large">Responsive</span></li>
					<li><span class="badge bg-violet large">Easy to Embed</span></li>
					<li><span class="badge bg-alt-blue large">Easy to Embed</span></li>
				</ul>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for Badges</small>
				<script src="https://gist.github.com/mrdogra007/1e84d0a59d7254b10d7ecd7b65335b25.js"></script>
			</div>
		</div>
		
		<!-- Style for buttons - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for &lt;button&gt; tag</span>
			</div>
		</div>
		<div class="horizontal">	
			<div class="verticals six">
				<ul class="inline m-t-20">
					<li><button class="button button-small">Button small</button></li>
					<li><button class="button">Button</button></li>
					<li><button class="button button-large">Button large</button></li>
				</ul>
				
				<ul class="inline m-t-20">
					<li><button class="button button-small disabled">Button small</button></li>
					<li><button class="button disabled">Button</button></li>
					<li><button class="button button-large disabled">Button large</button></li>
				</ul>
				
				<ul class="inline m-t-20">
					<li><button class="button bg-orange large">Button orange</button></li>
					<li><button class="button bg-purple large">Button purple</button></li>
					<li><button class="button bg-pink large">Button pink</button></li>
					<li><button class="button bg-red large">Button red</button></li>
					<li><button class="button bg-blue large">Button blue</button></li>
					<li><button class="button bg-green large">Button green</button></li>
					<li><button class="button bg-violet large">Button violet</button></li>
					<li><button class="button bg-alt-blue large">Button alt blue</button></li>
				</ul>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for button tags</small>
				<script src="https://gist.github.com/mrdogra007/115c0e71ade79d444f1d3710e24cc9c3.js"></script>
			</div>
		</div>
		
		<!-- Style for alert notifications - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for alert notifications</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals six">		
				<div class="alert bg-orange">Alert message in orange background</div>
				<div class="alert bg-purple">Alert message in purple background</div>
				<div class="alert bg-pink">Alert message in pink background</div>
				<div class="alert bg-red">Alert message in red background</div>
				<div class="alert bg-blue">Alert message in blue background</div>
				<div class="alert bg-green">Alert message in green background</div>
				<div class="alert bg-violet">Alert message in violet background</div>
				<div class="alert bg-alt-blue">Alert message in alt-blue background</div>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for alert notifications</small>
				<script src="https://gist.github.com/mrdogra007/b1c1100eab2355cc91b467f6d7d0fc36.js"></script>
			</div>
		</div>
		
		<!-- Style for alert notifications with subtext - <?php echo $force_framework_version ?> -->		
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for alert notifications with subtext</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals six">	
				<div class="alert bg-orange">
					Alert message in orange background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-purple">
					Alert message in purple background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-pink">
					Alert message in pink background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-red">
					Alert message in red background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-blue">
					Alert message in blue background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-green">
					Alert message in green background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-violet">
					Alert message in violet background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
				<div class="alert bg-alt-blue">
					Alert message in alt-blue background
					<span>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</span>
				</div>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for alert notifications with subtext</small>
				<script src="https://gist.github.com/mrdogra007/e96e3d196740ed5a4b9d638b5e7753af.js"></script>
			</div>
		</div>
		
		<!-- Style for Responsive tables - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for &lt;table&gt;</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals six">		
				<div class="force-table-responsive force-table-shadow">
					<table class="fluid">
						<thead>
							<tr>
								<th></th>
								<th>Contact</th>
								<th>Location</th>
								<th>Notes</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="verticals six">	
				<small class="green">Style for Responsive tables</small>
				<script src="https://gist.github.com/mrdogra007/ae1901929bd956e9a42ca6476c624057.js"></script>
			</div>
		</div>
		
		<!-- Style for Responsive tables with colored header background - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for compressed &lt;table&gt;</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals six">		
				<div class="force-table-responsive force-table-compressed force-table-shadow">
					<table class="fluid">
						<thead>
							<tr>
								<th></th>
								<th>Contact</th>
								<th>Location</th>
								<th>Notes</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="verticals six">	
				<small class="green">Style for Responsive compressed tables</small>
				<script src="https://gist.github.com/mrdogra007/ae1901929bd956e9a42ca6476c624057.js"></script>
			</div>
		</div>
		
		<!-- Style for Responsive tables with orange colored header background - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for &lt;table&gt; with dark header</span>
			</div>
		</div>
		<div class="horizontal">	
			<div class="verticals six">
				<div class="force-table-responsive force-table-shadow">
					<table class="fluid">
						<thead class="dark">
							<tr>
								<th></th>
								<th>Contact</th>
								<th>Location</th>
								<th>Notes</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for Responsive tables with dark header</small>
				<script src="https://gist.github.com/mrdogra007/841d0b3757faf39ab4e4c40e2da29ff7.js"></script>
			</div>
		</div>
		
		<!-- Style for Responsive tables with colored heading text - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for &lt;table&gt; with orange header</span>
			</div>
		</div>
		<div class="horizontal">	
			<div class="verticals six">
				<div class="force-table-responsive force-table-shadow">
					<table class="fluid">
						<thead class="bg-orange">
							<tr>
								<th></th>
								<th>Contact</th>
								<th>Location</th>
								<th>Notes</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-76966xxxxx</td>
								<td>Chandigarh</td>
								<td>Call not picked</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-94645xxxxx</td>
								<td>Andheri, Mumbai</td>
								<td>Busy, teveling</td>
								<td>Pending</td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox"/></td>
								<td>+91-83086xxxxx</td>
								<td>Shimla</td>
								<td>Call later</td>
								<td>Done</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="verticals six">
				<small class="green">Style for Responsive tables with orange header</small>
				<script src="https://gist.github.com/mrdogra007/cfd40b5e564a07d1cbea7e27bed9e00d.js"></script>
			</div>
		</div>
	
		<!-- Style for pagination - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals twelve">
				<span class="caption m-t-30">Style for pagination</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals six">
				<div class="pagination m-t-20">
					<a href="#">«</a>
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">5</a>
					<a href="#">6</a>
					<a href="#">›</a>
					<a href="#">»</a>
				</div>
				
				<div class="pagination m-t-20">
					<a href="#">First</a>
					<a href="#">Prev</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">5</a>
					<a href="#">6</a>
					<a href="#">Next</a>
					<a href="#">Last</a>
				</div>
				
				<div class="pagination m-t-20">
					<a href="#">Prev</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">5</a>
					<a href="#">Next</a>
				</div>
			</div>
			<div class="verticals six">
				<small class="green">Style for pagination</small>
				<script src="https://gist.github.com/mrdogra007/88694e9f6f0f18633a501c0a7d12dfa6.js"></script>
			</div>
		</div>
		
		<!-- Style for compact pagination - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals six">
				<div class="pagination small m-t-20">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination large">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
			</div>
			<div class="verticals six">
				<small class="green">Style for compact pagination</small>
				<script src="https://gist.github.com/mrdogra007/b61e2e79f2ec62e7806562d17248ddeb.js"></script>
			</div>
		</div>
			
		<!-- Style for compact colored pagination - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals six">
				<div class="pagination orange">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination blue">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination red">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination green">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination violet">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination pink">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination purple">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
				
				<div class="pagination alt-blue">
					<a href="#">‹</a>
					<a href="#" class="selected">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">›</a>
				</div>
			</div>
			<div class="verticals six">
				<small class="green">Style for colored pagination</small>
				<script src="https://gist.github.com/mrdogra007/61a918a61526fa84a4f722b174583315.js"></script>
			</div>
		</div>
		
		<!-- Style for unordered/ordered lists - <?php echo $force_framework_version ?> -->
		<div class="horizontal">
			<div class="verticals">
				<span class="caption m-t-30">Style for list types &lt;ul&gt; and &lt;ol&gt;</span>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals four">
				<ul>
					<li>Force List item 1</li>
					<li>Force List item 2</li>
					<li>Force List item 3</li>
					<li>
						Force List item 4
						<ul>
							<li>Force List item 4.1</li>
							<li>Force List item 4.2</li>
							<li>Force List item 4.3</li>
						</ul>
					</li>
					<li>Force List item 5</li>
					<li>Force List item 6</li>
					<li>Force List item 7</li>
				</ul>
			</div>
			
			<div class="verticals four">
				<ol>
					<li>Force List item 1</li>
					<li>Force List item 2</li>
					<li>Force List item 3</li>
					<li>
						Force List item 4
						<ol>
							<li>Force List item 4.1</li>
							<li>Force List item 4.2</li>
							<li>Force List item 4.3</li>
						</ol>
					</li>
					<li>Force List item 5</li>
					<li>Force List item 6</li>
					<li>Force List item 7</li>
				</ol>
			</div>
			
			<div class="verticals four">
				<ol>
					<li>Force List item 1</li>
					<li>Force List item 2</li>
					<li>Force List item 3</li>
					<li>
						Force List item 4
						<ol>
							<li>Force List item 4.1</li>
							<li>Force List item 4.2</li>
							<li>
								Force List item 4.3
								<ul>
									<li>Force List item 4.3.1</li>
									<li>Force List item 4.3.2</li>
									<li>Force List item 4.3.3</li>
								</ul>
							</li>
						</ol>
					</li>
					<li>Force List item 5</li>
				</ol>
			</div>
		</div>
		<div class="horizontal">
			<div class="verticals four">
				<small class="green">Style for unordered list</small>
				<script src="https://gist.github.com/mrdogra007/565dc44789aa42db31804144edd27ffe.js"></script>
			</div>
			<div class="verticals four">
				<small class="green">Style for ordered list</small>
				<script src="https://gist.github.com/mrdogra007/78e2c139582e8d4fe5f67f62cb568a32.js"></script>
			</div>
			<div class="verticals four">
				<small class="green">Style for unordered and ordered list</small>
				<script src="https://gist.github.com/mrdogra007/e3d3c5be752c6ece643a369f0a57e801.js"></script>
			</div>
		</div>
		
	</div>
</main>