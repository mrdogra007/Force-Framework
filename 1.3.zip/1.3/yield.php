<!-- <?php echo $force_framework_version ?> Header -->
<?php include 'force-intro.php';?>

<main role="main">
	<div class="container">
		
		<!-- <?php echo $force_framework_version ?> working guide -->
		<div class="horizontal">
			<div class="verticals ten offset-by-one text-center">
				<h2 class="purple">Force Framework <?php echo $force_framework_version ?> is open source. Hosted on GitHub</h2>
				<a href="https://github.com/mrdogra007/Force-Framework" class="button bg-purple large">Fork in Github</a>
				<a href="http://dograsweblog.com/drive/force-framework/1.3/documentation.php" class="button bg-orange large">View Documenation</a>
				<a href="http://dograsweblog.com/drive/force-framework/1.3/start-working.php" class="button bg-violet large">Start Working</a>
			</div>
		</div>
		
	</div>
</main>