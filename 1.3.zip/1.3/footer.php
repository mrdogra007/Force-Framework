<footer role="footer">
	<div class="container">
		<div class="horizontal">
			<div class="verticals ten">
				<div class="width-wrapper">
					<h3><em>Now page will load instantly</em></h3>
					<p>For the Designers &amp; Developer use.</p>
					
					<nav role="navigation">
						<strong>Force Framework</strong>
						<a href="">Blog</a>
						<a href="">Advertising</a>
						<a href="">Docs</a>
						<a href="">Support</a>
						<a href="">Shop</a>
					</nav>

					<nav role="navigation">
						<strong>Community</strong>
						<a href="">Meetups</a>
						<a href="">Teams</a>
						<a href="">Patterns</a>
						<a href="">Code of Conduct</a>
					</nav>
					
					<nav role="navigation">
						<strong>Author</strong>
						<a href="<?php echo $see_also_twitter ?>" rel="author">Twitter</a>
						<a href="<?php echo $see_also_github ?>" rel="author">GitHub</a>
						<a href="<?php echo $see_also_behance ?>" rel="author">Behance</a>
					</nav>
				</div>

				<div class="copyright m-t-30">
					<p>&#169; 2018 <?php echo $title ?></p>
				</div>
			</div>
			
			<div class="verticals two force-text-right">
				<picture class="logo">
					<img src="http://cloud.dograsweblog.com/force-framework/600x600.png" class="fit-image" alt="<?php echo $title ?>" data-title="<?php echo $title ?>"/>
				</picture>
			</div>
		</div>
	</div>
</footer>