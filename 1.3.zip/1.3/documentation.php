<html lang="en">
<head>
	<?php include 'meta-tag-main.php';?>
</head>

<body itemscope="" itemtype="http://schema.org/WebPage" role="document">

<?php include 'cta-github.php';?>
<?php include 'header.php';?>
<?php include 'yield-documentation.php';?>
<?php include 'footer.php';?>

</body>
</html>