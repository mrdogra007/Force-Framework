<header role="header" class="header-force-framework">
	<div class="container">
		<div class="horizontal">
			<div class="verticals two">
				<a href="http://dograsweblog.com/drive/force-framework/1.3/index.php">
					<picture class="logo">
						<img src="http://cloud.dograsweblog.com/force-framework/120x120.png" class="fit-image" alt="<?php echo $title ?>" data-title="<?php echo $title ?>"/>
					</picture>
				</a>
			</div>
			
			<div class="verticals ten">
				<nav class="primary-nav" role="navigation">
					<a href="http://dograsweblog.com/drive/force-framework/1.3/documentation.php">Documentation</a>
					<a href="http://dograsweblog.com/drive/force-framework/1.3/start-working.php">Start working</a>
				</nav>
			</div>
		</div>
	</div>
</header>