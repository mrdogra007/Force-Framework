// Image as checkbox plugin CSS & HTML only - Force Framework
// Deigned by Nishant Dogra
// Date: 08/03/2018
// Twitter: @mrdogra007
// Website: http://dograsweblog.com/drive/force-framework/