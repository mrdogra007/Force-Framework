A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/ZwdJbB.

 Pure CSS based 4 tabs plugin designed for Force Framework, easy to plug and play. Simple and clean, no javascript. Crafted on Force Framework. 