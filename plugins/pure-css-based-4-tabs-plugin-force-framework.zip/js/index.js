// Pure CSS based 4 tabs plugin
// Pure CSS based 4 tabs plugin designed for Force Framework, easy to plug and play
// Deigned by Nishant Dogra
// Created: 22/02/2019
// Twitter: @mrdogra007
// http://dograsweblog.com/drive/force-framework/