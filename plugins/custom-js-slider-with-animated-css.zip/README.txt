A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/YEXXgN.

 Custom JS slider with animated CSS for the stats type data widget Bootstrap compatible -  very nice plugin & widget for your website. If you have some reports to show or to display the multiple output in a small space. Then this is awesome. 