// Pagination plugin CSS & HTML only - Force Framework
// Deigned by Nishant Dogra
// Date: 20/08/2018
// Twitter: @mrdogra007
// Website: http://dograsweblog.com/drive/force-framework/