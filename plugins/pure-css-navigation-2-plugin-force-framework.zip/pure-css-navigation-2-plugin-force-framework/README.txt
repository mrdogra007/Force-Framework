A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/omVKag.

 Pure CSS navigation, no javascript used. Developed on Force Framework. Free to use plugin. Checkout more at Force Framework.