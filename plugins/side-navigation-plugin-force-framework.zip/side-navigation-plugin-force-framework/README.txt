A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/GOOxpR.

 Side navigation (multiple dropdown) for admin dashboard & themes - you can integrate this with your dashboard, portals and web application. Its clean and easy to use. Crafted on Force Framework by @mrdogra007 