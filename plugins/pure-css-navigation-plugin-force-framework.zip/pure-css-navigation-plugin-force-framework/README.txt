A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/GzQXMr.

 Pure CSS navigation - Hamburger type and mobile compatible side navigation, Crafted on Force Framework & Author Nishant Dogra. Checkout Framework: http://dograsweblog.com/drive/force-framework/