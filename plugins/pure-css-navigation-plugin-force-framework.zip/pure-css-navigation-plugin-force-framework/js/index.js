// Pure CSS navigation
// Hamburger and mobile compatible side navigation
// Crafted on: Force Framework
// Created: 09/02/2019
// Updated: 09-02-2019
// Author: Nishant Dogra
// Twitter: @mrdogra007
// http://dograsweblog.com/drive/force-framework/