// Notes plugin - Force Framework
// Deigned by Nishant Dogra
// Created: 27/03/2018
// Updated: 27/03/2018
// Twitter: @mrdogra007
// http://dograsweblog.com/drive/force-framework/