A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/GymvLM.

 Simple HTML/CSS Management Tree, Tree Architecture plugin -
* Easy to embed
* Bootstrap compatible
* Div based