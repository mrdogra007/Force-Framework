// Simple HTML/CSS Management Tree, Tree Architecture plugin - Force Framework
// Deigned by Nishant Dogra
// Date: 09/05/2018
// Twitter: @mrdogra007
// Website: http://dograsweblog.com/drive/force-framework/