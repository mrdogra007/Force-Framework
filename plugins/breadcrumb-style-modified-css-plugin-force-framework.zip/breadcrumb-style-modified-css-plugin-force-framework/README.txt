A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/JONzgy.

 Force Framework breadcrumb style, easily integration with HTML/CSS themes & application #ForceFramework @mrdogra007