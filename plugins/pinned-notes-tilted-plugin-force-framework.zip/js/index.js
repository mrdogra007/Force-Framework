// Notes scrolable plugin  - Force Framework
// Deigned by Nishant Dogra
// Created: 26/04/2018
// Updated: 26/04/2018
// Twitter: @mrdogra007
// http://dograsweblog.com/drive/force-framework/