A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/JxQJQr.

 Pure CSS based 3 tabs plugin designed for Force Framework, easy to plug and play