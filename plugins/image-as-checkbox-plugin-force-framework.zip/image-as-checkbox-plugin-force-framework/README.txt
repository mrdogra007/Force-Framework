A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/PEPKeW.

 Image as checkbox plugin CSS & HTML only - Force Framework - 
easy to use plugin for the dashboard elements to check image and submit #ForceFramework 
