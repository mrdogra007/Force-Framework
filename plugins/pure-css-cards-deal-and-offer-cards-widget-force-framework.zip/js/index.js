// Pure CSS cards - Force Framework
// Deal and Offer cards for ecommerce websites and stores, side widgets for offer cards
// Crafted on: Force Framework
// Created: 18/01/2018
// Updated: 18/02/2019
// Author: Nishant Dogra
// Twitter: @mrdogra007
// http://dograsweblog.com/drive/force-framework/