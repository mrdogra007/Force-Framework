A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/dZGbay.

 Pure CSS based Deal and Offer cards widget with label - Force Framework - its great for the shopping type of sites to show the multiple offers with the description. Crafted on Force Framework.